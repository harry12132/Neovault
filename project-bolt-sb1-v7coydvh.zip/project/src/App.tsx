import React, { useState } from 'react';
import { Wallet, ArrowUpRight, ArrowDownLeft, DollarSign, TrendingUp, Copy, Clock, Bell, ChevronRight } from 'lucide-react';

function App() {
  const [balance] = useState('2,458.92');
  const [priceChange] = useState('+2.3%');
  const [transactions] = useState([
    { id: 1, type: 'receive', amount: '500.00', from: 'Sarah Johnson', time: '2h ago' },
    { id: 2, type: 'send', amount: '120.50', to: 'Countdown NZ', time: '5h ago' },
    { id: 3, type: 'receive', amount: '800.00', from: 'John Smith', time: '1d ago' },
  ]);

  return (
    <div className="min-h-screen text-white">
      <div className="max-w-md mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-3">
            <div className="bg-gradient-to-br from-emerald-500/20 to-blue-500/20 p-2.5 rounded-2xl backdrop-blur-xl border border-white/5">
              <Wallet className="h-6 w-6 text-emerald-400" />
            </div>
            <h1 className="text-xl font-bold bg-gradient-to-r from-emerald-400 to-blue-400 bg-clip-text text-transparent">
              NeoVault
            </h1>
          </div>
          <button className="relative bg-gray-800/50 p-2.5 rounded-2xl backdrop-blur-xl border border-white/5">
            <Bell className="h-5 w-5 text-gray-400" />
            <span className="absolute top-1 right-1 h-2 w-2 bg-emerald-500 rounded-full ring-4 ring-black" />
          </button>
        </div>

        {/* Balance Card */}
        <div className="bg-gray-800/30 backdrop-blur-xl rounded-3xl p-8 mb-6 border border-white/5 shadow-[0_0_50px_-12px] shadow-emerald-500/10">
          <div className="text-center">
            <p className="text-gray-400 text-sm mb-2">Available Balance</p>
            <div className="flex items-center justify-center space-x-2 mb-1">
              <span className="text-2xl text-gray-400">NZD</span>
              <h2 className="text-5xl font-bold bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent animate-gradient bg-[length:200%_auto]">
                {balance}
              </h2>
            </div>
            <div className="flex items-center justify-center space-x-3 mb-8">
              <div className="flex items-center text-emerald-400 bg-emerald-400/10 px-3 py-1 rounded-full text-sm">
                <TrendingUp className="h-3 w-3 mr-1" />
                {priceChange} this month
              </div>
            </div>

            {/* Balance Chart Preview */}
            <div className="h-32 mb-8 flex items-end justify-between px-4">
              {[40, 65, 45, 70, 85, 60, 75, 90, 65, 80].map((height, i) => (
                <div
                  key={i}
                  className="w-1 rounded-full bg-gradient-to-t from-emerald-500 to-blue-500"
                  style={{ height: `${height}%` }}
                />
              ))}
            </div>

            {/* Action Buttons */}
            <div className="grid grid-cols-2 gap-4">
              <button className="group relative bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-2xl p-6 transition-all duration-300 shadow-lg shadow-emerald-500/20 hover:shadow-emerald-500/30 hover:scale-[1.02]">
                <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-white/0 via-white/10 to-white/0 opacity-0 group-hover:opacity-100 transition-opacity" />
                <div className="relative flex flex-col items-center">
                  <div className="bg-emerald-400/20 p-3 rounded-xl mb-2 group-hover:scale-110 transition-transform">
                    <ArrowUpRight className="h-6 w-6" />
                  </div>
                  <span className="font-medium">Send</span>
                </div>
              </button>

              <button className="group relative bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl p-6 transition-all duration-300 shadow-lg shadow-blue-500/20 hover:shadow-blue-500/30 hover:scale-[1.02]">
                <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-white/0 via-white/10 to-white/0 opacity-0 group-hover:opacity-100 transition-opacity" />
                <div className="relative flex flex-col items-center">
                  <div className="bg-blue-400/20 p-3 rounded-xl mb-2 group-hover:scale-110 transition-transform">
                    <ArrowDownLeft className="h-6 w-6" />
                  </div>
                  <span className="font-medium">Receive</span>
                </div>
              </button>
            </div>
          </div>
        </div>

        {/* Recent Transactions */}
        <div className="bg-gray-800/30 rounded-2xl backdrop-blur-xl border border-white/5 shadow-lg">
          <div className="p-4 border-b border-white/5">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Clock className="h-4 w-4 text-gray-400" />
                <h3 className="font-medium">Recent Transactions</h3>
              </div>
              <button className="text-sm text-gray-400 hover:text-white transition-colors flex items-center">
                View All
                <ChevronRight className="h-4 w-4 ml-1" />
              </button>
            </div>
          </div>
          <div className="divide-y divide-white/5">
            {transactions.map((tx) => (
              <div key={tx.id} className="p-4 hover:bg-white/5 transition-colors">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className={`p-2 rounded-xl ${
                      tx.type === 'receive' ? 'bg-emerald-400/10' : 'bg-blue-400/10'
                    }`}>
                      {tx.type === 'receive' ? (
                        <ArrowDownLeft className={`h-4 w-4 ${
                          tx.type === 'receive' ? 'text-emerald-400' : 'text-blue-400'
                        }`} />
                      ) : (
                        <ArrowUpRight className={`h-4 w-4 ${
                          tx.type === 'receive' ? 'text-emerald-400' : 'text-blue-400'
                        }`} />
                      )}
                    </div>
                    <div>
                      <p className="font-medium">
                        {tx.type === 'receive' ? 'Received from' : 'Sent to'}{' '}
                        <span className="text-gray-400">{tx.type === 'receive' ? tx.from : tx.to}</span>
                      </p>
                      <div className="flex items-center space-x-2">
                        <p className="text-sm font-medium">
                          NZD {tx.amount}
                        </p>
                      </div>
                    </div>
                  </div>
                  <span className="text-sm text-gray-400">{tx.time}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;